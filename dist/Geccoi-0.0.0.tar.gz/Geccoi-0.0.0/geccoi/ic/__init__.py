"""
Input Controller Package API to interface to the computers inputs.

By @GrandMoff100
"""

from .gmouse import GMouse
from .gkeyboard import GKeyboard